## maia_sample_engineering_metrics
Records weekly engineering team performance metrics including the volume of issues closed, average cycle time, and deployment activity.
Columns: record_id, team_id, issue_type_id, week, issues_closed, avg_cycle_time, deployments

## maia_sample_team
Provides reference information about engineering and support teams including their organizational structure, leadership, and staffing levels.
Columns: team_id, team_name, department, manager_name, headcount

## maia_sample_issue_type
Provides reference information about issue categories including their severity classification, typical resolution time, and escalation requirements.
Columns: issue_type_id, issue_type_name, severity_level, average_resolution_minutes, requires_escalation

## Data Relationships
maia_sample_engineering_metrics.team_id → maia_sample_team.team_id
maia_sample_engineering_metrics.issue_type_id → maia_sample_issue_type.issue_type_id

## Use Cases
As an AI Engineer, you can use these tables to build predictive models and analytics workflows that optimize team performance and issue resolution. Analyze maia_sample_engineering_metrics alongside maia_sample_team and maia_sample_issue_type to identify patterns in cycle time by team and issue severity, forecast deployment capacity, and recommend resource allocation strategies. This data enables you to develop machine learning models that predict issue resolution times and detect operational bottlenecks across your engineering organization.